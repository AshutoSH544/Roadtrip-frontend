import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import TripList from './pages/TripList';
import CreateTrip from './pages/CreateTrip';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/trips" element={<TripList />} />
        <Route path="/create" element={<CreateTrip />} />
      </Routes>
    </Router>
  );
}

export default App;