import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2025 RoadTrip Planner | Designed by Ashutosh</p>
    </footer>
  );
}