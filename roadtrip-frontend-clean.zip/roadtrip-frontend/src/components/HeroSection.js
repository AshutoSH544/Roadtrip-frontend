import React from 'react';

export default function HeroSection() {
  return (
    <div className="hero">
      <h2>Plan Your Next Adventure</h2>
      <p>Discover and create road trips across the globe</p>
      <input type="text" placeholder="Search a destination..." />
    </div>
  );
}