import React from 'react';

export default function TripCard({ trip }) {
  return (
    <div className="trip-card">
      <h3>{trip.title}</h3>
      <p>{trip.location}</p>
      <p>{trip.startDate} to {trip.endDate}</p>
    </div>
  );
}