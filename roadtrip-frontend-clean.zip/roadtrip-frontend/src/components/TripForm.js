import React, { useState } from 'react';

export default function TripForm({ onSubmit }) {
  const [trip, setTrip] = useState({ title: '', location: '', startDate: '', endDate: '' });

  const handleChange = (e) => {
    setTrip({ ...trip, [e.target.name]: e.target.value });
  };

  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(trip); }}>
      <input name="title" onChange={handleChange} placeholder="Trip Title" />
      <input name="location" onChange={handleChange} placeholder="Location" />
      <input name="startDate" onChange={handleChange} type="date" />
      <input name="endDate" onChange={handleChange} type="date" />
      <button type="submit">Create Trip</button>
    </form>
  );
}