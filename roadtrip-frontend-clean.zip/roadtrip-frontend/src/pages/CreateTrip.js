import React from 'react';
import TripForm from '../components/TripForm';
import { createTrip } from '../services/api';

export default function CreateTrip() {
  const handleCreate = (trip) => {
    createTrip(trip).then(() => alert('Trip Created!'));
  };

  return (
    <div>
      <h2>Create New Trip</h2>
      <TripForm onSubmit={handleCreate} />
    </div>
  );
}