import React, { useEffect, useState } from 'react';
import { getTrips } from '../services/api';
import TripCard from '../components/TripCard';

export default function TripList() {
  const [trips, setTrips] = useState([]);

  useEffect(() => {
    getTrips().then(response => setTrips(response.data));
  }, []);

  return (
    <div>
      <h2>Available Trips</h2>
      {trips.map(trip => <TripCard key={trip.id} trip={trip} />)}
    </div>
  );
}